import sys
import joblib
import pandas as pd

labels = [
    "MedInc",
    "HouseAge",
    "AveRooms",
    "AveBedrms",
    "Population",
    "AveOccup",
    "Latitude",
    "Longitude",
]

model = joblib.load("house_price_model.pkl")

if len(sys.argv) == 9:
    vals = [float(x) for x in sys.argv[1:]]
else:
    vals = []
    print("Enter values for prediction:\n")
    for name in labels:
        vals.append(float(input(f"{name}: ")))

row = pd.DataFrame([vals], columns=labels)
result = model.predict(row)[0]

print(f"\nPredicted price: ${result * 100000:,.0f}")
